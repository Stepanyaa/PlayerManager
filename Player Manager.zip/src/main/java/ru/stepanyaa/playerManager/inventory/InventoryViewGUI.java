package ru.stepanyaa.playerManager.inventory;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import ru.stepanyaa.playerManager.PlayerManager;
import ru.stepanyaa.playerManager.quit.QuitInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Completely reworked inventory viewer (v2.0.0).
 *
 * <p>The screen is split into two panels, exactly as requested:</p>
 * <ul>
 *   <li><b>Upper panel</b> - the inventory (or ender chest) of the inspected player,
 *       including armour and off-hand. It is fully editable, also while the player
 *       is offline; every change is stored and applied on the next join.</li>
 *   <li><b>Lower panel</b> - the control panel. The administrator's own inventory is
 *       temporarily replaced by eleven action buttons and is restored automatically
 *       when the screen closes (and even after a server restart, because the original
 *       contents are persisted).</li>
 * </ul>
 */
public class InventoryViewGUI implements Listener, InventoryHolder {

    /**
     * Button positions inside the bottom row of the screen, next to the
     * information item. The administrator's own inventory is never touched.
     */
    public static final int SLOT_BACK = 45;
    public static final int SLOT_PLAYER_MENU = 46;
    public static final int SLOT_ENDER = 47;
    public static final int SLOT_TELEPORT = 48;
    public static final int SLOT_INFO = 49;
    public static final int SLOT_COPY_UUID = 50;
    public static final int SLOT_STATS = 51;
    public static final int SLOT_EFFECTS = 52;
    public static final int SLOT_REFRESH = 53;
    /** First slot of the control row. */
    private static final int CONTROL_ROW = 45;

    /** Layout of the upper panel. */
    private static final int TOP_SIZE = 54;
    private static final int ARMOR_OFFSET = 36;
    private static final int OFFHAND_SLOT = 40;

    /** State of one open viewer. */
    private static class Session {
        final UUID targetUuid;
        boolean enderMode;
        Inventory top;

        Session(UUID targetUuid, boolean enderMode) {
            this.targetUuid = targetUuid;
            this.enderMode = enderMode;
        }
    }

    private final PlayerManager plugin;
    private final Map<UUID, Session> sessions = new HashMap<UUID, Session>();
    /** Guards against the close handler running while we reopen the screen ourselves. */
    private final Map<UUID, Boolean> reopening = new HashMap<UUID, Boolean>();

    public InventoryViewGUI(PlayerManager plugin) {
        this.plugin = plugin;
    }

    @Override
    public Inventory getInventory() {
        return null;
    }

    // ------------------------------------------------------------------
    // opening
    // ------------------------------------------------------------------

    public void openInventory(Player admin, UUID targetUuid) {
        open(admin, targetUuid, false);
    }

    public void openEnderChest(Player admin, UUID targetUuid) {
        open(admin, targetUuid, true);
    }

    public void open(Player admin, UUID targetUuid, boolean enderMode) {
        if (admin == null || targetUuid == null) {
            return;
        }
        plugin.useLanguageOf(admin);
        if (!admin.hasPermission("playermanager.admin") && !admin.hasPermission("playermanager.inventory")) {
            admin.sendMessage(ChatColor.RED + plugin.getMessage("error.no-permission", "You don't have permission!"));
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(targetUuid);
        String name = target.getName() == null ? targetUuid.toString() : target.getName();

        String titleKey = enderMode ? "gui.enderchest-title" : "gui.inventory-title";
        String titleDefault = enderMode ? "Ender chest: " : "Inventory: ";
        String title = plugin.getMessage(titleKey, titleDefault) + ChatColor.YELLOW + name;
        if (title.length() > 32) {
            title = title.substring(0, 32);
        }

        Session session = new Session(targetUuid, enderMode);
        Inventory top = Bukkit.createInventory(this, TOP_SIZE, title);
        session.top = top;
        fillTopPanel(session, target);
        sessions.put(admin.getUniqueId(), session);

        reopening.put(admin.getUniqueId(), Boolean.TRUE);
        admin.openInventory(top);
        reopening.remove(admin.getUniqueId());
        admin.updateInventory();
    }

    /** Rebuilds both panels without closing the screen. */
    public void refresh(Player admin) {
        Session session = sessions.get(admin.getUniqueId());
        if (session == null) {
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(session.targetUuid);
        fillTopPanel(session, target);
        admin.updateInventory();
    }

    private void fillTopPanel(Session session, OfflinePlayer target) {
        Inventory top = session.top;
        top.clear();

        Player online = target.getPlayer();
        if (session.enderMode) {
            ItemStack[] contents = (online != null)
                    ? online.getEnderChest().getContents()
                    : plugin.getOfflineInventoryManager().loadEnderChest(session.targetUuid);
            if (contents != null) {
                for (int i = 0; i < contents.length && i < 27; i++) {
                    top.setItem(i, contents[i]);
                }
            }
            ItemStack filler = pane(Material.BLACK_STAINED_GLASS_PANE, " ");
            for (int i = 27; i < 45; i++) {
                top.setItem(i, filler);
            }
        } else {
            ItemStack[] storage;
            if (online != null) {
                storage = new ItemStack[OfflineInventoryManager.STORAGE_SIZE];
                PlayerInventory inventory = online.getInventory();
                for (int i = 0; i < 36; i++) {
                    storage[i] = inventory.getItem(i);
                }
                ItemStack[] armor = inventory.getArmorContents();
                for (int i = 0; i < 4 && i < armor.length; i++) {
                    storage[ARMOR_OFFSET + i] = armor[i];
                }
                storage[OFFHAND_SLOT] = inventory.getItemInOffHand();
            } else {
                storage = plugin.getOfflineInventoryManager().loadInventory(session.targetUuid);
            }
            if (storage != null) {
                for (int i = 0; i < storage.length && i < OfflineInventoryManager.STORAGE_SIZE; i++) {
                    top.setItem(i, storage[i]);
                }
            }
            ItemStack filler = pane(Material.GRAY_STAINED_GLASS_PANE, " ");
            for (int i = 41; i < 45; i++) {
                top.setItem(i, filler);
            }
        }

        // Информационная строка внизу верхней панели.
        ItemStack info = new ItemStack(Material.BOOK);
        ItemMeta meta = info.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.AQUA + (target.getName() == null ? "?" : target.getName()));
            List<String> lore = new ArrayList<String>();
            boolean online2 = target.isOnline();
            lore.add(ChatColor.GRAY + plugin.getMessage("gui.status", "Status") + ": "
                    + plugin.getActivityStatusManager().render(online2,
                    online2 ? System.currentTimeMillis() : lastSeen(session.targetUuid)));
            if (!online2) {
                long snapshot = plugin.getOfflineInventoryManager().getSnapshotTime(session.targetUuid);
                lore.add(ChatColor.GRAY + plugin.getMessage("gui.snapshot-time", "Snapshot") + ": "
                        + ChatColor.WHITE + (snapshot > 0L ? plugin.formatDatePublic(snapshot) : "-"));
                lore.add(ChatColor.YELLOW + plugin.getMessage("gui.offline-edit-hint",
                        "Changes are saved and applied on the next join"));
            }
            meta.setLore(lore);
            info.setItemMeta(meta);
        }
        buildControlRow(session, info);
    }

    // ------------------------------------------------------------------
    // control row (bottom row of the upper panel)
    // ------------------------------------------------------------------

    /** Places the control buttons in the bottom row, around the information item. */
    private void buildControlRow(Session session, ItemStack info) {
        Inventory top = session.top;
        for (int i = CONTROL_ROW; i < TOP_SIZE; i++) {
            top.setItem(i, pane(Material.BLACK_STAINED_GLASS_PANE, " "));
        }

        top.setItem(SLOT_BACK, button(Material.ARROW,
                plugin.getMessage("gui.button-back", "&cGo back"), null));
        top.setItem(SLOT_PLAYER_MENU, button(Material.PLAYER_HEAD,
                plugin.getMessage("gui.button-player-menu", "&eOpen player menu"), null));
        top.setItem(SLOT_ENDER, button(Material.ENDER_CHEST,
                session.enderMode
                        ? plugin.getMessage("gui.button-inventory", "&dOpen inventory")
                        : plugin.getMessage("gui.button-enderchest", "&dOpen ender chest"), null));
        top.setItem(SLOT_TELEPORT, button(Material.ENDER_PEARL,
                plugin.getMessage("gui.button-teleport", "&bTeleport"), null));
        top.setItem(SLOT_INFO, info);
        top.setItem(SLOT_COPY_UUID, button(Material.NAME_TAG,
                plugin.getMessage("gui.button-copy-uuid", "&fCopy UUID"),
                ChatColor.GRAY + session.targetUuid.toString()));
        top.setItem(SLOT_STATS, button(Material.PAPER,
                plugin.getMessage("gui.button-stats", "&aStatistics"), null));
        top.setItem(SLOT_EFFECTS, button(Material.POTION,
                plugin.getMessage("gui.button-effects", "&5Active effects"), null));
        top.setItem(SLOT_REFRESH, button(Material.SUNFLOWER,
                plugin.getMessage("gui.button-refresh", "&eRefresh"), null));
    }

    private long lastSeen(UUID uuid) {
        long logout = plugin.getPlayerDataConfig().getLong("players." + uuid + ".last_logout", 0L);
        if (logout > 0L) {
            return logout;
        }
        return plugin.getPlayerDataConfig().getLong("players." + uuid + ".last_login", 0L);
    }

    // ------------------------------------------------------------------
    // control panel
    // ------------------------------------------------------------------

    private ItemStack button(Material material, String name, String loreLine) {
        ItemStack item = new ItemStack(material == null ? Material.STONE : material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            if (loreLine != null) {
                List<String> lore = new ArrayList<String>();
                lore.add(ChatColor.translateAlternateColorCodes('&', loreLine));
                meta.setLore(lore);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack pane(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            item.setItemMeta(meta);
        }
        return item;
    }

    // ------------------------------------------------------------------
    // administrator inventory backup
    // ------------------------------------------------------------------

    /**
     * Restores items that an older version of the plugin moved out of the way
     * when it still filled the administrator's own inventory with buttons.
     *
     * <p>The viewer no longer touches the administrator's inventory at all, so
     * this only does something when such a backup still exists. Safe to call
     * multiple times.</p>
     */
    public void restoreAdminInventory(Player admin) {
        String path = "admin." + admin.getUniqueId() + ".saved_inventory";
        String encoded = plugin.getPlayerDataConfig().getString(path);
        if (encoded == null) {
            return;
        }
        admin.getInventory().clear();
        ItemStack[] contents = plugin.getOfflineInventoryManager().decode(encoded);
        if (contents != null) {
            int size = admin.getInventory().getSize();
            for (int i = 0; i < contents.length && i < size; i++) {
                admin.getInventory().setItem(i, contents[i]);
            }
        }
        plugin.getPlayerDataConfig().set(path, null);
        plugin.savePlayerDataConfig();
        admin.updateInventory();
    }

    /** Called on plugin disable so nobody keeps a screen full of buttons. */
    public void closeAll() {
        for (UUID uuid : new ArrayList<UUID>(sessions.keySet())) {
            Player admin = Bukkit.getPlayer(uuid);
            if (admin != null) {
                persistTopPanel(admin, sessions.get(uuid));
                admin.closeInventory();
                restoreAdminInventory(admin);
            }
        }
        sessions.clear();
    }

    // ------------------------------------------------------------------
    // events
    // ------------------------------------------------------------------

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        Player admin = (Player) event.getWhoClicked();
        Session session = sessions.get(admin.getUniqueId());
        if (session == null) {
            return;
        }
        for (int raw : event.getRawSlots()) {
            if (raw >= TOP_SIZE) {
                // The administrator's own inventory stays untouched and usable.
                continue;
            }
            boolean decorative = session.enderMode ? (raw >= 27) : (raw >= 41);
            if (decorative) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        Player admin = (Player) event.getWhoClicked();
        final Session session = sessions.get(admin.getUniqueId());
        if (session == null) {
            return;
        }
        Inventory clicked = event.getClickedInventory();
        if (clicked == null) {
            event.setCancelled(true);
            return;
        }

        // ---------- lower panel: the administrator's own inventory ----------
        if (clicked.equals(admin.getInventory())) {
            // Nothing of ours lives here any more, leave it alone.
            return;
        }

        // ---------- upper panel: the inspected inventory ----------
        if (!(clicked.getHolder() instanceof InventoryViewGUI)) {
            return;
        }
        int slot = event.getSlot();
        if (slot >= CONTROL_ROW) {
            // Bottom row: control buttons.
            event.setCancelled(true);
            handleButton(admin, session, slot);
            return;
        }
        boolean decorative = session.enderMode ? (slot >= 27) : (slot >= 41);
        boolean editable = plugin.getConfig().getBoolean("inventory-viewer.allow-editing", true)
                && admin.hasPermission("playermanager.inventory.edit");
        if (decorative || !editable) {
            event.setCancelled(true);
            return;
        }
        // The edit itself is allowed; persist it one tick later, once Bukkit applied it.
        Bukkit.getScheduler().runTask(plugin, new Runnable() {
            @Override
            public void run() {
                persistTopPanel(null, session);
            }
        });
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player)) {
            return;
        }
        Player admin = (Player) event.getPlayer();
        if (Boolean.TRUE.equals(reopening.get(admin.getUniqueId()))) {
            return;
        }
        Session session = sessions.remove(admin.getUniqueId());
        if (session == null) {
            return;
        }
        persistTopPanel(admin, session);
        restoreAdminInventory(admin);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Session session = sessions.remove(event.getPlayer().getUniqueId());
        if (session != null) {
            persistTopPanel(event.getPlayer(), session);
            restoreAdminInventory(event.getPlayer());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        // Recover the real items if the server stopped while the panel was open.
        String path = "admin." + event.getPlayer().getUniqueId() + ".saved_inventory";
        if (plugin.getPlayerDataConfig().getString(path) != null) {
            restoreAdminInventory(event.getPlayer());
        }
    }

    // ------------------------------------------------------------------
    // persistence of the inspected inventory
    // ------------------------------------------------------------------

    private void persistTopPanel(Player admin, Session session) {
        if (session == null || session.top == null) {
            return;
        }
        if (!plugin.getConfig().getBoolean("inventory-viewer.allow-editing", true)) {
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(session.targetUuid);
        Player online = target.getPlayer();

        if (session.enderMode) {
            ItemStack[] contents = OfflineInventoryManager.contentsOf(session.top, 27);
            if (online != null) {
                online.getEnderChest().setContents(contents);
                plugin.getOfflineInventoryManager().snapshot(online);
            } else {
                plugin.getOfflineInventoryManager().saveEnderChest(session.targetUuid, contents);
            }
            return;
        }

        ItemStack[] storage = OfflineInventoryManager.contentsOf(session.top, OfflineInventoryManager.STORAGE_SIZE);
        if (online != null) {
            PlayerInventory inventory = online.getInventory();
            for (int i = 0; i < 36; i++) {
                inventory.setItem(i, storage[i]);
            }
            ItemStack[] armor = new ItemStack[4];
            System.arraycopy(storage, ARMOR_OFFSET, armor, 0, 4);
            inventory.setArmorContents(armor);
            inventory.setItemInOffHand(storage[OFFHAND_SLOT]);
            online.updateInventory();
            plugin.getOfflineInventoryManager().snapshot(online);
        } else {
            plugin.getOfflineInventoryManager().saveInventory(session.targetUuid, storage);
        }
    }

    // ------------------------------------------------------------------
    // buttons
    // ------------------------------------------------------------------

    private void handleButton(final Player admin, final Session session, int slot) {
        final UUID targetUuid = session.targetUuid;
        final OfflinePlayer target = Bukkit.getOfflinePlayer(targetUuid);

        switch (slot) {
            case SLOT_BACK: {
                persistTopPanel(admin, session);
                sessions.remove(admin.getUniqueId());
                admin.closeInventory();
                plugin.getPlayerSearchGUI().openLastGUIMenu(admin);
                break;
            }
            case SLOT_PLAYER_MENU: {
                persistTopPanel(admin, session);
                sessions.remove(admin.getUniqueId());
                admin.closeInventory();
                plugin.getPlayerSearchGUI().openPlayerMenuByUuid(admin, targetUuid.toString());
                break;
            }
            case SLOT_ENDER: {
                persistTopPanel(admin, session);
                open(admin, targetUuid, !session.enderMode);
                break;
            }
            case SLOT_TELEPORT: {
                teleport(admin, target, targetUuid);
                break;
            }
            case SLOT_COPY_UUID: {
                sendCopyableUuid(admin, targetUuid);
                break;
            }
            case SLOT_STATS: {
                sendStatistics(admin, target);
                break;
            }
            case SLOT_EFFECTS: {
                sendEffects(admin, target);
                break;
            }
            case SLOT_REFRESH: {
                persistTopPanel(admin, session);
                refresh(admin);
                admin.sendMessage(ChatColor.GREEN + plugin.getMessage("action.refreshed", "Contents refreshed"));
                break;
            }
            default:
                break;
        }
    }

    private void teleport(Player admin, OfflinePlayer target, UUID targetUuid) {
        Player online = target.getPlayer();
        if (online != null) {
            admin.closeInventory();
            restoreAdminInventory(admin);
            sessions.remove(admin.getUniqueId());
            admin.teleport(online.getLocation());
            admin.sendMessage(ChatColor.GREEN + plugin.getMessage("action.teleported", "Teleported to ") + online.getName());
            return;
        }

        QuitInfo info = plugin.getQuitTracker().getQuitInfo(targetUuid);
        if (info == null) {
            admin.sendMessage(ChatColor.RED + plugin.getMessage("error.no-last-location",
                    "No last known location for this player."));
            return;
        }
        World world = Bukkit.getWorld(info.getWorld());
        if (world == null) {
            admin.sendMessage(ChatColor.RED + plugin.getMessage("error.world-not-found", "World not found: ")
                    + info.getWorld());
            return;
        }
        admin.closeInventory();
        restoreAdminInventory(admin);
        sessions.remove(admin.getUniqueId());
        admin.teleport(new Location(world, info.getX(), info.getY(), info.getZ()));
        admin.sendMessage(ChatColor.GREEN + plugin.getMessage("action.teleported-last-location",
                "Teleported to the last known location."));
    }

    private void sendCopyableUuid(Player admin, UUID uuid) {
        String label = plugin.getMessage("action.uuid-copy", "Click to copy the UUID");
        TextComponent component = new TextComponent(ChatColor.GRAY + "UUID: " + ChatColor.WHITE + uuid);
        component.setClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, uuid.toString()));
        component.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                new ComponentBuilder(label).create()));
        admin.spigot().sendMessage(component);
    }

    private void sendStatistics(Player admin, OfflinePlayer target) {
        admin.sendMessage(ChatColor.GOLD + "── " + plugin.getMessage("gui.button-stats", "Statistics")
                + ": " + ChatColor.YELLOW + (target.getName() == null ? "?" : target.getName()) + ChatColor.GOLD + " ──");
        try {
            int playTicks = target.getStatistic(Statistic.PLAY_ONE_MINUTE);
            admin.sendMessage(ChatColor.GRAY + plugin.getMessage("stats.playtime", "Playtime") + ": "
                    + ChatColor.WHITE + (playTicks / 20 / 3600) + "h " + ((playTicks / 20 / 60) % 60) + "m");
            admin.sendMessage(ChatColor.GRAY + plugin.getMessage("stats.deaths", "Deaths") + ": "
                    + ChatColor.WHITE + target.getStatistic(Statistic.DEATHS));
            admin.sendMessage(ChatColor.GRAY + plugin.getMessage("stats.player-kills", "Player kills") + ": "
                    + ChatColor.WHITE + target.getStatistic(Statistic.PLAYER_KILLS));
            admin.sendMessage(ChatColor.GRAY + plugin.getMessage("stats.mob-kills", "Mob kills") + ": "
                    + ChatColor.WHITE + target.getStatistic(Statistic.MOB_KILLS));
        } catch (Throwable throwable) {
            admin.sendMessage(ChatColor.RED + plugin.getMessage("error.no-statistics",
                    "No statistics available for this player."));
        }
    }

    private void sendEffects(Player admin, OfflinePlayer target) {
        Player online = target.getPlayer();
        if (online == null) {
            admin.sendMessage(ChatColor.RED + plugin.getMessage("error.player-offline", "Player is offline!"));
            return;
        }
        admin.sendMessage(ChatColor.GOLD + "── " + plugin.getMessage("gui.button-effects", "Active effects")
                + ": " + ChatColor.YELLOW + online.getName() + ChatColor.GOLD + " ──");
        if (online.getActivePotionEffects().isEmpty()) {
            admin.sendMessage(ChatColor.GRAY + plugin.getMessage("gui.no-effects", "No active effects"));
            return;
        }
        for (PotionEffect effect : online.getActivePotionEffects()) {
            int seconds = effect.getDuration() / 20;
            admin.sendMessage(ChatColor.GRAY + "• " + ChatColor.WHITE + effect.getType().getName()
                    + ChatColor.GRAY + " " + (effect.getAmplifier() + 1)
                    + ChatColor.DARK_GRAY + " (" + seconds + "s)");
        }
    }

    public boolean hasSession(Player admin) {
        return sessions.containsKey(admin.getUniqueId());
    }
}
