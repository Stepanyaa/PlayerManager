package ru.stepanyaa.playerManager.inventory;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;
import ru.stepanyaa.playerManager.storage.DataStore;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Stores the inventory and the ender chest of every player inside
 * {@code player_data.yml} so administrators can inspect <b>and edit</b> them
 * while the player is offline.
 *
 * <p>Edits made to an offline player are written back to the snapshot and applied
 * automatically the next time that player joins, which is exactly the behaviour
 * requested for v2.0.0.</p>
 */
public class OfflineInventoryManager implements Listener {

    public static final int STORAGE_SIZE = 41; // 36 main + 4 armor + 1 offhand
    public static final int ENDER_SIZE = 27;

    private final Plugin plugin;
    private final FileConfiguration data;
    private final Runnable saver;
    /** v2.0.0: the heavy payloads live here, not in player_data.yml. */
    private final DataStore store;

    public OfflineInventoryManager(Plugin plugin, FileConfiguration data, Runnable saver, DataStore store) {
        this.plugin = plugin;
        this.data = data;
        this.saver = saver;
        this.store = store;
    }

    // ------------------------------------------------------------------
    // listeners
    // ------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        snapshot(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        applyPendingEdits(event.getPlayer());
    }

    /** Saves the current contents of an online player. */
    public void snapshot(Player player) {
        if (player == null) {
            return;
        }
        UUID uuid = player.getUniqueId();
        PlayerInventory inventory = player.getInventory();

        ItemStack[] storage = new ItemStack[STORAGE_SIZE];
        for (int i = 0; i < 36; i++) {
            storage[i] = inventory.getItem(i);
        }
        ItemStack[] armor = inventory.getArmorContents();
        for (int i = 0; i < 4 && i < armor.length; i++) {
            storage[36 + i] = armor[i];
        }
        storage[40] = inventory.getItemInOffHand();

        // Serializing is cheap; storing is a memory write that the storage layer
        // flushes asynchronously, so a quitting player never stalls the server.
        long now = System.currentTimeMillis();
        store.setBlob(uuid, DataStore.TYPE_INVENTORY, serialize(storage), now);
        store.setBlob(uuid, DataStore.TYPE_ENDERCHEST, serialize(player.getEnderChest().getContents()), now);
    }

    /**
     * Applies edits that an administrator performed while the player was offline.
     */
    public void applyPendingEdits(final Player player) {
        final UUID uuid = player.getUniqueId();
        final boolean hasInventoryEdit = data.getBoolean("players." + uuid + ".inventory_dirty", false);
        final boolean hasEnderEdit = data.getBoolean("players." + uuid + ".enderchest_dirty", false);
        if (!hasInventoryEdit && !hasEnderEdit) {
            return;
        }

        Bukkit.getScheduler().runTaskLater(plugin, new Runnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    return;
                }
                if (hasInventoryEdit) {
                    ItemStack[] storage = loadInventory(uuid);
                    if (storage != null) {
                        PlayerInventory inventory = player.getInventory();
                        for (int i = 0; i < 36; i++) {
                            inventory.setItem(i, storage[i]);
                        }
                        ItemStack[] armor = new ItemStack[4];
                        System.arraycopy(storage, 36, armor, 0, 4);
                        inventory.setArmorContents(armor);
                        inventory.setItemInOffHand(storage[40]);
                        player.updateInventory();
                    }
                    data.set("players." + uuid + ".inventory_dirty", null);
                }
                if (hasEnderEdit) {
                    ItemStack[] ender = loadEnderChest(uuid);
                    if (ender != null) {
                        player.getEnderChest().setContents(resize(ender, ENDER_SIZE));
                    }
                    data.set("players." + uuid + ".enderchest_dirty", null);
                }
                save();
                String message = plugin.getConfig().getString("offline-inventory.notify-message", "");
                if (message != null && !message.isEmpty()) {
                    player.sendMessage(org.bukkit.ChatColor.translateAlternateColorCodes('&', message));
                }
            }
        }, Math.max(1L, plugin.getConfig().getLong("offline-inventory.apply-delay-ticks", 20L)));
    }

    // ------------------------------------------------------------------
    // reading / writing snapshots
    // ------------------------------------------------------------------

    /** @return the stored 41-slot layout, or {@code null} when nothing was stored yet. */
    public ItemStack[] loadInventory(UUID uuid) {
        ItemStack[] items = deserialize(store.getBlob(uuid, DataStore.TYPE_INVENTORY));
        return items == null ? null : resize(items, STORAGE_SIZE);
    }

    public ItemStack[] loadEnderChest(UUID uuid) {
        ItemStack[] items = deserialize(store.getBlob(uuid, DataStore.TYPE_ENDERCHEST));
        return items == null ? null : resize(items, ENDER_SIZE);
    }

    /** Persists an administrator edit for an offline player. */
    public void saveInventory(UUID uuid, ItemStack[] storage) {
        store.setBlob(uuid, DataStore.TYPE_INVENTORY, serialize(resize(storage, STORAGE_SIZE)),
                System.currentTimeMillis());
        data.set("players." + uuid + ".inventory_dirty", true);
        save();
    }

    public void saveEnderChest(UUID uuid, ItemStack[] contents) {
        store.setBlob(uuid, DataStore.TYPE_ENDERCHEST, serialize(resize(contents, ENDER_SIZE)),
                System.currentTimeMillis());
        data.set("players." + uuid + ".enderchest_dirty", true);
        save();
    }

    public long getSnapshotTime(UUID uuid) {
        long time = store.getBlobTime(uuid, DataStore.TYPE_INVENTORY);
        return time > 0L ? time : data.getLong("players." + uuid + ".inventory_updated", 0L);
    }

    public boolean hasSnapshot(UUID uuid) {
        return store.hasBlob(uuid, DataStore.TYPE_INVENTORY);
    }

    /** Copies the contents of a GUI inventory into a fixed size array. */
    public static ItemStack[] resize(ItemStack[] source, int size) {
        ItemStack[] target = new ItemStack[size];
        if (source != null) {
            System.arraycopy(source, 0, target, 0, Math.min(source.length, size));
        }
        return target;
    }

    public static ItemStack[] contentsOf(Inventory inventory, int size) {
        ItemStack[] items = new ItemStack[size];
        for (int i = 0; i < size && i < inventory.getSize(); i++) {
            items[i] = inventory.getItem(i);
        }
        return items;
    }

    // ------------------------------------------------------------------
    // serialization
    // ------------------------------------------------------------------

    /** Public helper used to store the administrator's own inventory while the control panel is open. */
    public String encode(ItemStack[] items) {
        return serialize(items);
    }

    /** Public counterpart of {@link #encode(ItemStack[])}. */
    public ItemStack[] decode(String encoded) {
        return deserialize(encoded);
    }

    private String serialize(ItemStack[] items) {
        if (items == null) {
            return null;
        }
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        BukkitObjectOutputStream output = null;
        try {
            output = new BukkitObjectOutputStream(buffer);
            output.writeInt(items.length);
            for (ItemStack item : items) {
                output.writeObject(item);
            }
            output.flush();
            return Base64Coder.encodeLines(buffer.toByteArray());
        } catch (Throwable throwable) {
            plugin.getLogger().log(Level.WARNING, "Could not serialize an inventory", throwable);
            return null;
        } finally {
            close(output);
        }
    }

    private ItemStack[] deserialize(String encoded) {
        if (encoded == null || encoded.isEmpty()) {
            return null;
        }
        BukkitObjectInputStream input = null;
        try {
            ByteArrayInputStream buffer = new ByteArrayInputStream(Base64Coder.decodeLines(encoded));
            input = new BukkitObjectInputStream(buffer);
            int length = input.readInt();
            if (length < 0 || length > 128) {
                return null;
            }
            ItemStack[] items = new ItemStack[length];
            for (int i = 0; i < length; i++) {
                Object value = input.readObject();
                items[i] = (value instanceof ItemStack) ? (ItemStack) value : null;
            }
            return items;
        } catch (Throwable throwable) {
            plugin.getLogger().log(Level.WARNING, "Could not read a stored inventory", throwable);
            return null;
        } finally {
            close(input);
        }
    }

    private void close(java.io.Closeable closeable) {
        if (closeable == null) {
            return;
        }
        try {
            closeable.close();
        } catch (Throwable ignored) {
            // nothing useful to do here
        }
    }

    private void save() {
        if (saver != null) {
            saver.run();
        }
    }
}
