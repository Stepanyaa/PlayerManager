package ru.stepanyaa.playerManager.jail;

import org.bukkit.plugin.Plugin;
import ru.stepanyaa.playerManager.util.TimeUtil;

/**
 * AdvancedBan adapter. AdvancedBan itself has no jails, so jail punishments are
 * mapped onto its temporary mute/ban system with a jail tag inside the reason.
 * All commands stay configurable so admins can re-map them.
 */
public class AdvancedBanJailProvider extends CommandJailProvider {

    public AdvancedBanJailProvider(Plugin owner) {
        super(owner, "AdvancedBan", "AdvancedBan");
        commands("tempmute %player% %time% [JAIL:%jail%] %reason%", "unmute %player%");
        permanentCommand("mute %player% [JAIL:%jail%] %reason%");
        capabilities(true, true, true);
    }

    @Override
    protected String formatDuration(long seconds) {
        // AdvancedBan expects "10m", "3h", "7d" style input.
        return TimeUtil.toShortForm(seconds);
    }
}
