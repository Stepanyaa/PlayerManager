package ru.stepanyaa.playerManager.jail;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.Plugin;
import ru.stepanyaa.playerManager.util.TimeUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Generic, fully configurable jail provider that works by dispatching console
 * commands. Every concrete provider in this package extends this class, which
 * is why adding support for a brand new jail plugin usually only means passing
 * different command templates to the constructor.
 *
 * <p>Supported placeholders inside the command templates:</p>
 * <ul>
 *     <li>{@code %player%} - target name</li>
 *     <li>{@code %uuid%} - target UUID</li>
 *     <li>{@code %jail%} - selected jail name</li>
 *     <li>{@code %time%} - duration in the plugin specific format</li>
 *     <li>{@code %seconds%} / {@code %minutes%} - raw duration</li>
 *     <li>{@code %reason%} - punishment reason</li>
 *     <li>{@code %admin%} - who issued the punishment</li>
 * </ul>
 */
public class CommandJailProvider implements JailProvider {

    protected final Plugin owner;
    private final String name;
    private final String pluginName;

    private String jailCommand;
    private String permanentJailCommand;
    private String unjailCommand;
    private String listCommand;

    private boolean supportsPermanent = true;
    private boolean supportsTimed = true;
    private boolean supportsOffline = false;

    /** Jails that were discovered from the backing plugin (or configured manually). */
    private final List<JailInfo> staticJails = new ArrayList<JailInfo>();

    public CommandJailProvider(Plugin owner, String name, String pluginName) {
        this.owner = owner;
        this.name = name;
        this.pluginName = pluginName;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getPluginName() {
        return pluginName;
    }

    @Override
    public boolean isAvailable() {
        if (pluginName == null || pluginName.isEmpty()) {
            // Command-only providers are always "available" once configured.
            return jailCommand != null && !jailCommand.isEmpty();
        }
        Plugin plugin = Bukkit.getPluginManager().getPlugin(pluginName);
        return plugin != null && plugin.isEnabled();
    }

    @Override
    public List<JailInfo> getJails() {
        return Collections.unmodifiableList(new ArrayList<JailInfo>(staticJails));
    }

    @Override
    public boolean jailPlayer(CommandSender executor, OfflinePlayer target, String jail, long durationSeconds, String reason) {
        boolean permanent = durationSeconds <= 0L;
        String template = permanent && permanentJailCommand != null && !permanentJailCommand.isEmpty()
                ? permanentJailCommand
                : jailCommand;
        if (template == null || template.isEmpty()) {
            return false;
        }
        return dispatch(executor, apply(template, target, jail, durationSeconds, reason, executor));
    }

    @Override
    public boolean unjailPlayer(CommandSender executor, OfflinePlayer target) {
        if (unjailCommand == null || unjailCommand.isEmpty()) {
            return false;
        }
        return dispatch(executor, apply(unjailCommand, target, null, 0L, "", executor));
    }

    @Override
    public boolean supportsPermanent() {
        return supportsPermanent;
    }

    @Override
    public boolean supportsTimed() {
        return supportsTimed;
    }

    @Override
    public boolean supportsOffline() {
        return supportsOffline;
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    /**
     * Replaces every placeholder. The duration is rendered with
     * {@link #formatDuration(long)} so each provider can use its own syntax.
     */
    protected String apply(String template, OfflinePlayer target, String jail, long durationSeconds,
                           String reason, CommandSender executor) {
        String playerName = target.getName();
        if (playerName == null || playerName.isEmpty()) {
            playerName = target.getUniqueId().toString();
        }
        String safeReason = (reason == null) ? "" : reason.trim();
        String adminName = executor == null ? "CONSOLE" : executor.getName();

        String out = template;
        out = out.replace("%player%", playerName);
        out = out.replace("%uuid%", target.getUniqueId().toString());
        out = out.replace("%jail%", jail == null ? "" : jail);
        out = out.replace("%time%", durationSeconds <= 0L ? permanentKeyword() : formatDuration(durationSeconds));
        out = out.replace("%seconds%", String.valueOf(Math.max(0L, durationSeconds)));
        out = out.replace("%minutes%", String.valueOf(Math.max(0L, durationSeconds / 60L)));
        out = out.replace("%reason%", safeReason);
        out = out.replace("%admin%", adminName);

        // Collapse the double spaces that appear when an optional placeholder was empty.
        while (out.contains("  ")) {
            out = out.replace("  ", " ");
        }
        return out.trim();
    }

    /** Duration syntax used by this plugin. Overridden where needed. */
    protected String formatDuration(long seconds) {
        return TimeUtil.toShortForm(seconds);
    }

    /** Keyword the plugin expects for a permanent punishment. */
    protected String permanentKeyword() {
        return "permanent";
    }

    protected boolean dispatch(CommandSender executor, String command) {
        if (command == null || command.isEmpty()) {
            return false;
        }
        final String clean = command.startsWith("/") ? command.substring(1) : command;
        if (Bukkit.isPrimaryThread()) {
            return Bukkit.dispatchCommand(Bukkit.getConsoleSender(), clean);
        }
        Bukkit.getScheduler().runTask(owner, new Runnable() {
            @Override
            public void run() {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), clean);
            }
        });
        return true;
    }

    /**
     * Reads a list of jail names from a plugin owned YAML/text file. Providers
     * use this as a last resort when the plugin exposes no API.
     */
    protected List<JailInfo> namesToJails(Iterable<String> names) {
        List<JailInfo> jails = new ArrayList<JailInfo>();
        if (names == null) {
            return jails;
        }
        for (String raw : names) {
            if (raw == null) {
                continue;
            }
            String trimmed = raw.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            jails.add(new JailInfo(trimmed, capitalize(trimmed)));
        }
        return jails;
    }

    protected static String capitalize(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }
        return input.substring(0, 1).toUpperCase(Locale.ROOT) + input.substring(1);
    }

    // ------------------------------------------------------------------
    // configuration
    // ------------------------------------------------------------------

    public CommandJailProvider commands(String jailCommand, String unjailCommand) {
        this.jailCommand = jailCommand;
        this.unjailCommand = unjailCommand;
        return this;
    }

    public CommandJailProvider permanentCommand(String permanentJailCommand) {
        this.permanentJailCommand = permanentJailCommand;
        return this;
    }

    public CommandJailProvider listCommand(String listCommand) {
        this.listCommand = listCommand;
        return this;
    }

    public CommandJailProvider capabilities(boolean permanent, boolean timed, boolean offline) {
        this.supportsPermanent = permanent;
        this.supportsTimed = timed;
        this.supportsOffline = offline;
        return this;
    }

    public String getListCommand() {
        return listCommand;
    }

    public String getJailCommand() {
        return jailCommand;
    }

    public String getUnjailCommand() {
        return unjailCommand;
    }

    protected void setStaticJails(List<JailInfo> jails) {
        this.staticJails.clear();
        if (jails != null) {
            this.staticJails.addAll(jails);
        }
    }

    protected List<JailInfo> rawStaticJails() {
        return staticJails;
    }
}
