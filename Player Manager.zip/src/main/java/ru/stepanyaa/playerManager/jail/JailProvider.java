package ru.stepanyaa.playerManager.jail;

import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Universal Jail API.
 *
 * <p>Every supported jail plugin is wrapped in its own implementation of this
 * interface. Adding support for a new plugin only requires a new class and a
 * single registration line inside {@link JailManager} - no other code has to
 * change.</p>
 */
public interface JailProvider {

    /** Human readable provider name, e.g. {@code EssentialsX}. */
    String getName();

    /** Name of the Bukkit plugin this provider depends on, or {@code null} for command-only providers. */
    String getPluginName();

    /** @return true when the backing plugin is installed and enabled. */
    boolean isAvailable();

    /** @return every jail known to the backing plugin. Never {@code null}. */
    List<JailInfo> getJails();

    /**
     * Sends a player to jail.
     *
     * @param executor        who requested the punishment (used for logging / command source)
     * @param target          the punished player, may be offline
     * @param jail            jail name, may be {@code null} when the plugin has a single default jail
     * @param durationSeconds duration in seconds, or {@code -1} for a permanent jail
     * @param reason          punishment reason, never {@code null}
     * @return true when the punishment was dispatched successfully
     */
    boolean jailPlayer(CommandSender executor, OfflinePlayer target, String jail, long durationSeconds, String reason);

    /** Releases a player from jail. */
    boolean unjailPlayer(CommandSender executor, OfflinePlayer target);

    /** @return true when the plugin understands permanent jails. */
    boolean supportsPermanent();

    /** @return true when the plugin understands timed jails. */
    boolean supportsTimed();

    /** @return true when the plugin can jail players that are currently offline. */
    boolean supportsOffline();
}
