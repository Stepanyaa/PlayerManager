package ru.stepanyaa.playerManager.quit;

/**
 * Snapshot of the moment a player disconnected. Powers the new
 * "Recently left" filter ("Недавно вышел"), which is mainly used to catch
 * cheaters that log out to avoid a staff check.
 */
public class QuitInfo {

    /** Sub categories offered by the "Recently left" filter. */
    public enum Category {
        UNDER_MINUTE("under_minute", 60L),
        UNDER_5_MINUTES("under_5_minutes", 300L),
        UNDER_10_MINUTES("under_10_minutes", 600L),
        UNDER_30_MINUTES("under_30_minutes", 1800L),
        UNDER_HOUR("under_hour", 3600L),
        TODAY("today", 86400L),
        YESTERDAY("yesterday", 172800L);

        private final String id;
        private final long maxSeconds;

        Category(String id, long maxSeconds) {
            this.id = id;
            this.maxSeconds = maxSeconds;
        }

        public String getId() {
            return id;
        }

        public long getMaxSeconds() {
            return maxSeconds;
        }

        /** @return the narrowest category matching the given age, or {@code null}. */
        public static Category of(long secondsAgo) {
            for (Category category : values()) {
                if (secondsAgo < category.maxSeconds) {
                    return category;
                }
            }
            return null;
        }
    }

    private final long time;
    private final String server;
    private final String world;
    private final double x;
    private final double y;
    private final double z;
    private final String reason;
    private final boolean inCombat;

    public QuitInfo(long time, String server, String world, double x, double y, double z,
                    String reason, boolean inCombat) {
        this.time = time;
        this.server = server;
        this.world = world;
        this.x = x;
        this.y = y;
        this.z = z;
        this.reason = reason;
        this.inCombat = inCombat;
    }

    public long getTime() {
        return time;
    }

    public String getServer() {
        return server == null ? "?" : server;
    }

    public String getWorld() {
        return world == null ? "?" : world;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }

    public String getReason() {
        return reason == null ? "" : reason;
    }

    /** @return true when the player disconnected while fighting - shown with a ⚔ icon. */
    public boolean isInCombat() {
        return inCombat;
    }

    public long secondsAgo() {
        if (time <= 0L) {
            return Long.MAX_VALUE;
        }
        return Math.max(0L, (System.currentTimeMillis() - time) / 1000L);
    }

    public Category category() {
        return Category.of(secondsAgo());
    }

    public String formatCoordinates() {
        return String.format("%s: %.1f, %.1f, %.1f", getWorld(), x, y, z);
    }
}
