package ru.stepanyaa.playerManager.quit;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Records where, when and why a player disconnected, and whether they were in
 * combat at that moment. This is what powers the new "Recently left" filter.
 */
public class QuitTracker implements Listener {

    private final Plugin plugin;
    private final FileConfiguration data;
    private final Runnable saver;

    /** uuid -> timestamp of the last combat interaction. */
    private final Map<UUID, Long> lastCombat = new HashMap<UUID, Long>();
    /** uuid -> kick reason, captured before the quit event fires. */
    private final Map<UUID, String> pendingKickReason = new HashMap<UUID, String>();

    public QuitTracker(Plugin plugin, FileConfiguration data, Runnable saver) {
        this.plugin = plugin;
        this.data = data;
        this.saver = saver;
    }

    private long combatWindowMillis() {
        return Math.max(1L, plugin.getConfig().getLong("quit-tracking.combat-seconds", 15L)) * 1000L;
    }

    private String serverName() {
        String configured = plugin.getConfig().getString("quit-tracking.server-name", "");
        if (configured != null && !configured.trim().isEmpty()) {
            return configured.trim();
        }
        String motd = Bukkit.getServer().getMotd();
        return (motd == null || motd.trim().isEmpty()) ? "server" : motd.trim();
    }

    // ------------------------------------------------------------------
    // listeners
    // ------------------------------------------------------------------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        Player victim = event.getEntity() instanceof Player ? (Player) event.getEntity() : null;
        Player attacker = resolveAttacker(event.getDamager());
        long now = System.currentTimeMillis();
        if (victim != null) {
            lastCombat.put(victim.getUniqueId(), now);
        }
        if (attacker != null) {
            lastCombat.put(attacker.getUniqueId(), now);
        }
    }

    private Player resolveAttacker(Entity damager) {
        if (damager instanceof Player) {
            return (Player) damager;
        }
        if (damager instanceof Projectile) {
            // ProjectileSource lives in org.bukkit.projectiles; Object keeps this
            // compatible across every supported API version.
            Object shooter = ((Projectile) damager).getShooter();
            if (shooter instanceof Player) {
                return (Player) shooter;
            }
        }
        return null;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onKick(PlayerKickEvent event) {
        String reason = event.getReason();
        pendingKickReason.put(event.getPlayer().getUniqueId(),
                (reason == null || reason.isEmpty()) ? "Kicked" : reason);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        if (!plugin.getConfig().getBoolean("quit-tracking.enabled", true)) {
            return;
        }
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        Location location = player.getLocation();

        Long combatAt = lastCombat.remove(uuid);
        boolean inCombat = combatAt != null && (System.currentTimeMillis() - combatAt) <= combatWindowMillis();

        String reason = pendingKickReason.remove(uuid);
        if (reason == null) {
            reason = plugin.getConfig().getString("quit-tracking.default-reason", "Disconnected");
        }
        if (player.isBanned()) {
            reason = plugin.getConfig().getString("quit-tracking.banned-reason", "Banned");
        }

        String path = "players." + uuid + ".last_quit";
        data.set(path + ".time", System.currentTimeMillis());
        data.set(path + ".server", serverName());
        data.set(path + ".world", location.getWorld() == null ? "?" : location.getWorld().getName());
        data.set(path + ".x", location.getX());
        data.set(path + ".y", location.getY());
        data.set(path + ".z", location.getZ());
        data.set(path + ".reason", reason);
        data.set(path + ".in_combat", inCombat);
        save();
    }

    // ------------------------------------------------------------------
    // lookup
    // ------------------------------------------------------------------

    /** @return the stored quit snapshot, or {@code null} when the player never left. */
    public QuitInfo getQuitInfo(UUID uuid) {
        ConfigurationSection section = data.getConfigurationSection("players." + uuid + ".last_quit");
        if (section == null) {
            return null;
        }
        long time = section.getLong("time", 0L);
        if (time <= 0L) {
            return null;
        }
        return new QuitInfo(
                time,
                section.getString("server", "?"),
                section.getString("world", "?"),
                section.getDouble("x", 0.0D),
                section.getDouble("y", 0.0D),
                section.getDouble("z", 0.0D),
                section.getString("reason", ""),
                section.getBoolean("in_combat", false));
    }

    /** @return true when the player left within the "Recently left" window (48 hours). */
    public boolean leftRecently(UUID uuid) {
        QuitInfo info = getQuitInfo(uuid);
        return info != null && info.category() != null;
    }

    public boolean isInCombat(Player player) {
        Long combatAt = lastCombat.get(player.getUniqueId());
        return combatAt != null && (System.currentTimeMillis() - combatAt) <= combatWindowMillis();
    }

    private void save() {
        if (saver != null) {
            saver.run();
        }
    }
}
