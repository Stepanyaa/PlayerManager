package ru.stepanyaa.playerManager.util;

import org.bukkit.ChatColor;

/**
 * A single configurable activity badge, e.g. "🟢 Online now" or "⚫ Not seen for over a year".
 */
public class ActivityStatus {

    private final String id;
    private final String icon;
    private final String color;
    private final String text;
    /** Upper bound in seconds. {@code -1} means "everything above the previous bound". */
    private final long maxSeconds;

    public ActivityStatus(String id, String icon, String color, String text, long maxSeconds) {
        this.id = id;
        this.icon = icon == null ? "" : icon;
        this.color = color == null ? "&7" : color;
        this.text = text == null ? "" : text;
        this.maxSeconds = maxSeconds;
    }

    public String getId() {
        return id;
    }

    public String getIcon() {
        return icon;
    }

    public String getColor() {
        return color;
    }

    public String getText() {
        return text;
    }

    public long getMaxSeconds() {
        return maxSeconds;
    }

    public boolean matches(long secondsSinceSeen) {
        return maxSeconds < 0L || secondsSinceSeen < maxSeconds;
    }

    /** @return the coloured badge ready to be used in an item name or lore line. */
    public String render() {
        String prefix = icon.isEmpty() ? "" : icon + " ";
        return ChatColor.translateAlternateColorCodes('&', color + prefix + text);
    }

    /** @return the badge without the icon, for places where emoji do not render. */
    public String renderPlain() {
        return ChatColor.translateAlternateColorCodes('&', color + text);
    }

    /** @return the {@link ChatColor} equivalent of the configured colour code. */
    public ChatColor toChatColor() {
        String translated = ChatColor.translateAlternateColorCodes('&', color);
        for (ChatColor value : ChatColor.values()) {
            if (translated.contains(value.toString())) {
                return value;
            }
        }
        return ChatColor.GRAY;
    }
}
