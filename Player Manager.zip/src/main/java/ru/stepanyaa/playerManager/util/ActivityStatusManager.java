package ru.stepanyaa.playerManager.util;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Builds the activity badges ("временные плашки активности") from config.yml.
 *
 * <p>Both the icon, the colour and the text of every badge are configurable, and
 * administrators may add, remove or reorder entries freely. The list is evaluated
 * top to bottom and the first entry whose {@code max-seconds} bound is not yet
 * exceeded wins; an entry with {@code max-seconds: -1} acts as the catch all.</p>
 */
public class ActivityStatusManager {

    private final Plugin plugin;
    private final List<ActivityStatus> statuses = new ArrayList<ActivityStatus>();
    private ActivityStatus onlineStatus;
    private boolean enabled = true;

    public ActivityStatusManager(Plugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        statuses.clear();
        FileConfiguration config = plugin.getConfig();
        enabled = config.getBoolean("activity-status.enabled", true);

        ConfigurationSection onlineSection = config.getConfigurationSection("activity-status.online");
        if (onlineSection != null) {
            onlineStatus = new ActivityStatus(
                    "online",
                    onlineSection.getString("icon", "🟢"),
                    onlineSection.getString("color", "&a"),
                    onlineSection.getString("text", "Online now"),
                    0L);
        } else {
            onlineStatus = new ActivityStatus("online", "🟢", "&a", "Online now", 0L);
        }

        List<Map<?, ?>> raw = config.getMapList("activity-status.statuses");
        if (raw != null) {
            for (Map<?, ?> entry : raw) {
                ActivityStatus status = fromMap(entry);
                if (status != null) {
                    statuses.add(status);
                }
            }
        }

        if (statuses.isEmpty()) {
            applyDefaults();
        }
    }

    private ActivityStatus fromMap(Map<?, ?> entry) {
        if (entry == null) {
            return null;
        }
        String id = string(entry.get("id"), "status");
        String icon = string(entry.get("icon"), "");
        String color = string(entry.get("color"), "&7");
        String text = string(entry.get("text"), "");
        long maxSeconds = seconds(entry);
        return new ActivityStatus(id, icon, color, text, maxSeconds);
    }

    /** Accepts {@code max-seconds}, {@code max-minutes}, {@code max-hours} and {@code max-days}. */
    private long seconds(Map<?, ?> entry) {
        Object value = entry.get("max-seconds");
        if (value != null) {
            return asLong(value);
        }
        value = entry.get("max-minutes");
        if (value != null) {
            long minutes = asLong(value);
            return minutes < 0L ? -1L : minutes * 60L;
        }
        value = entry.get("max-hours");
        if (value != null) {
            long hours = asLong(value);
            return hours < 0L ? -1L : hours * 3600L;
        }
        value = entry.get("max-days");
        if (value != null) {
            long days = asLong(value);
            return days < 0L ? -1L : days * 86400L;
        }
        return -1L;
    }

    private static long asLong(Object value) {
        if (value instanceof Number) {
            return ((Number) value).longValue();
        }
        try {
            return Long.parseLong(String.valueOf(value).trim());
        } catch (NumberFormatException ignored) {
            return -1L;
        }
    }

    private static String string(Object value, String fallback) {
        return value == null ? fallback : String.valueOf(value);
    }

    private void applyDefaults() {
        statuses.add(new ActivityStatus("just_now", "🟢", "&a", "Seen just now", 300L));
        statuses.add(new ActivityStatus("within_hour", "🟡", "&e", "Seen less than an hour ago", 3600L));
        statuses.add(new ActivityStatus("today", "🟠", "&6", "Seen today", 86400L));
        statuses.add(new ActivityStatus("yesterday", "🔵", "&b", "Seen yesterday", 172800L));
        statuses.add(new ActivityStatus("week", "🟣", "&d", "Not seen for a week", 604800L));
        statuses.add(new ActivityStatus("month", "🔴", "&c", "Not seen for a month", 2592000L));
        statuses.add(new ActivityStatus("over_month", "⚫", "&8", "Not seen for over a month", 7776000L));
        statuses.add(new ActivityStatus("over_3_months", "⚫", "&8", "Not seen for over 3 months", 15552000L));
        statuses.add(new ActivityStatus("over_6_months", "⚫", "&8", "Not seen for over half a year", 31536000L));
        statuses.add(new ActivityStatus("over_year", "⚫", "&8", "Not seen for over a year", -1L));
    }

    public boolean isEnabled() {
        return enabled;
    }

    public ActivityStatus getOnlineStatus() {
        return onlineStatus;
    }

    public List<ActivityStatus> getStatuses() {
        return new ArrayList<ActivityStatus>(statuses);
    }

    /**
     * Resolves the badge for a player.
     *
     * @param online       whether the player is currently connected
     * @param lastSeenMillis timestamp of the last login/logout, {@code 0} when unknown
     */
    public ActivityStatus resolve(boolean online, long lastSeenMillis) {
        if (online) {
            return onlineStatus;
        }
        long secondsSinceSeen;
        if (lastSeenMillis <= 0L) {
            secondsSinceSeen = Long.MAX_VALUE;
        } else {
            secondsSinceSeen = Math.max(0L, (System.currentTimeMillis() - lastSeenMillis) / 1000L);
        }
        for (ActivityStatus status : statuses) {
            if (status.matches(secondsSinceSeen)) {
                return status;
            }
        }
        if (!statuses.isEmpty()) {
            return statuses.get(statuses.size() - 1);
        }
        return new ActivityStatus("unknown", "⚫", "&8", "Unknown", -1L);
    }

    /** Convenience wrapper returning the ready to display badge. */
    public String render(boolean online, long lastSeenMillis) {
        return resolve(online, lastSeenMillis).render();
    }
}
