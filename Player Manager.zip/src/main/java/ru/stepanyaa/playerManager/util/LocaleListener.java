package ru.stepanyaa.playerManager.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLocaleChangeEvent;
import ru.stepanyaa.playerManager.PlayerManager;

/**
 * Keeps the cached client language of every player up to date.
 *
 * <p>{@code PlayerLocaleChangeEvent} exists on Spigot and Paper since 1.12, but
 * the listener is registered inside a try/catch by the plugin so an exotic fork
 * without the event simply keeps the language detected at join time.</p>
 */
public class LocaleListener implements Listener {

    private final PlayerManager plugin;

    public LocaleListener(PlayerManager plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onLocaleChange(PlayerLocaleChangeEvent event) {
        final Player player = event.getPlayer();
        // The new locale is applied to the player a tick later on some
        // versions, so the cache is refreshed on the next tick.
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                plugin.getMessageManager().cacheLocale(player);
            }
        });
    }
}
